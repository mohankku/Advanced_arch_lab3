./procsim -r 3 -f 4 -j 2 -k 1 -l 2 -b 1 -e 10000000 -i ../traces/bzip2.ptr.gz > bzip2.output
./procsim -r 3 -f 4 -j 2 -k 1 -l 2 -b 1 -e 10000000 -i ../traces/gcc.ptr.gz > gcc.output
./procsim -r 3 -f 4 -j 2 -k 1 -l 2 -b 1 -e 10000000 -i ../traces/libq.ptr.gz > libq.output
./procsim -r 3 -f 4 -j 2 -k 1 -l 2 -b 1 -e 10000000 -i ../traces/mcf.ptr.gz > mcf.output
./procsim -r 3 -f 4 -j 2 -k 1 -l 2 -b 1 -e 100 -i ../traces/sml.ptr.gz > sml.output
